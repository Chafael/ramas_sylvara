package com.example.sylvara_frontend

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
